import { Component, OnInit } from '@angular/core';
import { ApiService } from './services/api.service';

@Component({
  selector: 'app-root',
  template: `
    <div>
      <h1>Lista de Productos</h1>
      <ul>
        <li *ngFor="let producto of productos">
          {{ producto.id }} - {{ producto.nombre }}: ${{ producto.precio }}
        </li>
      </ul>
    </div>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'despliegue';
  productos: any[] = [];

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.apiService.getProductos().subscribe((data: any) => {
      this.productos = data;
    });
  }
  
}

